﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DITECFP
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonStudent_Click(object sender, EventArgs e)
        {
            Students s = new Students();
            s.Show();
            this.Hide();
        }

        private void buttonTeachers_Click(object sender, EventArgs e)
        {
            Teachers t = new Teachers();
            t.Show();
            this.Hide();
        }
    }
}
